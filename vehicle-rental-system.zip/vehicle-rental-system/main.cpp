#include <iostream>
#include <string>
#include "vehicle.cpp"
#include "car.cpp"
#include "truck.cpp"

const int MAX_VEHICLES = 10;

int main() {
    Vehicle* vehicles[MAX_VEHICLES] = {}; // Initialize array with nullptrs
    int numVehicles = 0;

    // Create some test vehicles
    Car* car1 = new Car("Toyota", "Corolla", 2019, 29.99, 5);
    vehicles[numVehicles++] = car1;

    Car* car2 = new Car("Honda", "Accord", 2020, 34.99, 5);
    vehicles[numVehicles++] = car2;

    Truck* truck1 = new Truck("Ford", "F-150", 2021, 44.99, 0.75);
    vehicles[numVehicles++] = truck1;

    // Display all vehicles
    std::cout << "Available vehicles:" << std::endl;
    for (int i = 0; i < numVehicles; i++) {
        std::cout << i+1 << ". ";
        vehicles[i]->display();
    }

    // Rent a vehicle
    std::cout << std::endl << "Which vehicle would you like to rent? ";
    int choice;
    std::cin >> choice;

    if (choice >= 1 && choice <= numVehicles) {
        Vehicle* chosenVehicle = vehicles[choice-1];
        if (!chosenVehicle->isRented()) {
            chosenVehicle->setRented(true);
            std::cout << "You have rented the following vehicle:" << std::endl;
            chosenVehicle->display();
        } else {
            std::cout << "Sorry, that vehicle is already rented." << std::endl;
        }
    } else {
        std::cout << "Invalid choice." << std::endl;
    }

    // Return rented vehicle
    std::cout << std::endl << "Would you like to return your rented vehicle? (y/n) ";
    char response;
    std::cin >> response;
    if (response == 'y' || response == 'Y') {
        for (int i = 0; i < numVehicles; i++) {
            if (vehicles[i]->isRented()) {
                vehicles[i]->setRented(false);
                std::cout << "Vehicle returned. Thank you for using our service." << std::endl;
                break;
            }
        }
    }

    // Free memory
    for (int i = 0; i < numVehicles; i++) {
        delete vehicles[i];
    }

    return 0;
}

