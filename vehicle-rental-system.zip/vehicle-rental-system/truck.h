#ifndef TRUCK_H
#define TRUCK_H

#include "Vehicle.h"

class Truck : public Vehicle {
private:
    double payloadCapacity;
public:
    Truck(std::string make, std::string model, int year, double pricePerDay, double payloadCapacity);
    void display() const;
};

#endif

