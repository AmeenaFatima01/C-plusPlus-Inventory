#ifndef CAR_H
#define CAR_H

#include "Vehicle.h"

class Car : public Vehicle {
private:
    int numSeats;
public:
    Car(std::string make, std::string model, int year, double pricePerDay, int numSeats);
    void display() const;
};

#endif

