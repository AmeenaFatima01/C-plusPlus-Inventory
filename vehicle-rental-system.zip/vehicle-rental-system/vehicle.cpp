#include "vehicle.h"
#include <iostream>

Vehicle::Vehicle(std::string make, std::string model, int year, double pricePerDay) {
    this->make = make;
    this->model = model;
    this->year = year;
    this->pricePerDay = pricePerDay;
    this->rented = false;
}

void Vehicle::display() const {
    std::cout << make << " " << model << " (" << year << "), $" << pricePerDay << " per day";
    if (rented) {
        std::cout << " (RENTED)";
    }
    std::cout << std::endl;
}

std::string Vehicle::getMake() const {
    return make;
}

std::string Vehicle::getModel() const {
    return model;
}

int Vehicle::getYear() const {
    return year;
}

double Vehicle::getPricePerDay() const {
    return pricePerDay;
}

bool Vehicle::isRented() const {
    return rented;
}

void Vehicle::setRented(bool rented) {
    this->rented = rented;
}

