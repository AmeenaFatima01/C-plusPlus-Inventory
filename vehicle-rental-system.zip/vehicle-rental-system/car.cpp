#include "car.h"
#include <iostream>

Car::Car(std::string make, std::string model, int year, double pricePerDay, int numSeats)
    : Vehicle(make, model, year, pricePerDay) {
    this->numSeats = numSeats;
}

void Car::display() const {
    std::cout << numSeats << "-seat ";
    Vehicle::display();
}

