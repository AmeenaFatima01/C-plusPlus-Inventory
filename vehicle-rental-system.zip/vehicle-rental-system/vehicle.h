#ifndef VEHICLE_H
#define VEHICLE_H

#include <string>

class Vehicle {
protected:
    std::string make;
    std::string model;
    int year;
    double pricePerDay;
    bool rented;
public:
    Vehicle(std::string make, std::string model, int year, double pricePerDay);
    virtual ~Vehicle() {}
    virtual void display() const;
    std::string getMake() const;
    std::string getModel() const;
    int getYear() const;
    double getPricePerDay() const;
    bool isRented() const;
    void setRented(bool rented);
};

#endif

