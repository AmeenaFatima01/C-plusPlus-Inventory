#include "truck.h"
#include <iostream>

Truck::Truck(std::string make, std::string model, int year, double pricePerDay, double payloadCapacity)
    : Vehicle(make, model, year, pricePerDay) {
    this->payloadCapacity = payloadCapacity;
}

void Truck::display() const {
    std::cout << "Truck with " << payloadCapacity << " ton payload capacity, ";
    Vehicle::display();
}

